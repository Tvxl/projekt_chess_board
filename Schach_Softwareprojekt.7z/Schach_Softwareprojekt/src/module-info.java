/**
 * 
 */
/**
 * 
 */
module Schach_Softwareprojekt {
	requires java.desktop;
}