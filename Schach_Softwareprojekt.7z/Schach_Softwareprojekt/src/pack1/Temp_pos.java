package pack1;

public class Temp_pos {

	public Temp_pos() {
		
		
		
	}

}
